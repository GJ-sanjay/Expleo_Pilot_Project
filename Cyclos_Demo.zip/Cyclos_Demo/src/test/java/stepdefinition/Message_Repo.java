package stepdefinition;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Message_Repo {
	
	//message icon
		@FindBy(id="messages-link")
		public static WebElement message_icon;
		
		//new message 
		@FindBy(xpath="//div[text()='New message']")
		public static WebElement new_message;
		
		//sent to 
		@FindBy(xpath="//button[@id='id_317']")
		public static WebElement sent_to;
		
		//sent to - user
		@FindBy(linkText="User")
		public static WebElement user;
		
		//to user
		@FindBy(xpath="//div[@class='d-flex']//button[1]")
		public static WebElement to_user;
		
		//to user-name 
		@FindBy(linkText="Hotel Oasis")
		public static WebElement hotel_oasis;
		
		//Administration
		@FindBy(xpath="//div[text()='Administration']")
		public static WebElement administration;
		
		//category
		@FindBy(xpath="//div[contains(@class,'w-100 open')]//button[1]")
		public static WebElement category;
		
		//subject
		@FindBy(xpath="(//input[contains(@class,'form-control w-100')]")
		public static WebElement subject;
		
		//text box
		@FindBy(className="editor")
		public static WebElement description;
		
		@FindBy(xpath="//span[text()='Send']")
		public static WebElement send;
		
		@FindBy(xpath="//label[text()=' Inbox ']")
		public static WebElement inbox;
		
		@FindBy(xpath="//a[@tabindex='0']")
		public static WebElement from;
		
		@FindBy(xpath="//a[@tabindex='0']")
		public static WebElement inbox_user;
		
		@FindBy(xpath="(//span[text()='Keywords']/following::input)[1]")
		public static WebElement keyword;
		
		@FindBy(xpath="//input[@value='sent']")
		public static WebElement sent;
		
		@FindBy(xpath="//a[@tabindex=\"0\"]")
		public static WebElement sentTo;
		
		@FindBy(xpath="//div[@class='d-flex']//button[1]")
		public static WebElement User;
		
		@FindBy(linkText="Demo one")
		public static WebElement Demo_one;
		
		@FindBy(xpath="(//span[text()='Keywords']/following::input)[1]")
		public static WebElement Keyword;
		
		




}
