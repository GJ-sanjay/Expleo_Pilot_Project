package stepdefinition;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AlertsLoggingRepo {
	
	@FindBy(xpath="//div[@class='menu-text'])[3]")
	public static WebElement marketPlace;
	
	@FindBy(xpath="//div[text()='Advertisements']")
	public static WebElement advertisements;
	
	@FindBy(xpath="//button[@type='button']//span[1]")
	public static WebElement show_adv;
	
	@FindBy(xpath="//button[@type='button']//span[1]")
	public static WebElement select_adv;
	
	@FindBy(xpath="//button[@class='btn']//div)[3]")
	public static WebElement ask_qsn;
	
	@FindBy(tagName="textarea")
	public static WebElement question;
	
	@FindBy(xpath="(//button[contains(@class,'btn d-flex')])[1]")
	public static WebElement submit;
	

}
