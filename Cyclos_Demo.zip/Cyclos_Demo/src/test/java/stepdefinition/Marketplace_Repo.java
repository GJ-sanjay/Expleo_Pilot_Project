package stepdefinition;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Marketplace_Repo {
	
	//Rich text for advertisement editing
		@FindBy(xpath="//div[text()='Marketplace']")
		public static WebElement marketplace;
		
		@FindBy(xpath="//div[text()='My advertisements']")
		public static WebElement my_adv;
		
		@FindBy(css="input.form-control.w-100")
		public static WebElement name;
		
		@FindBy(xpath="//a[@tabindex=\"0\"]")
		public static WebElement category;
		
		@FindBy(css="input[type='tel']")
		public static WebElement price;
		
		@FindBy(xpath="//input[@type='date'])[1]")
		public static WebElement Begin_Date;
		
		@FindBy(xpath="(//input[@type='date'])[2]")
		public static WebElement End_Date;
		
		@FindBy(className="editor")
		public static WebElement description;
		
		@FindBy(xpath="//span[text()='Save']")
		public static WebElement save;
		
		
		//To schedule an address per advertisement
		@FindBy(xpath="//div[@class='dropdown-menu show']")
		public static WebElement address;
		
		//To customise the search filters according to the given parameters
		@FindBy(xpath="//span[text()='Advertisements']")
		public static WebElement Advertisement;
		
		@FindBy(css="div.action-label")
		public static WebElement more_filter;
		
		@FindBy(xpath="//input[contains(@class,'form-control w-100')]")
		public static WebElement Keyword;
		
		@FindBy(className="custom-control-label")
		public static WebElement favarite;
		
		@FindBy(xpath="//input[@placeholder='0,00'])[1]")
		public static WebElement min_price;
		
		@FindBy(xpath="//input[@placeholder='0,00'])[2]")
		public static WebElement max_price;
		
		@FindBy(xpath="//span[text()='Show advertisements']")
		public static WebElement show_adv;
		


}
